${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_FILES='wildcard.o libgnu_wc.a'
NEW_LIBS="${NEW_FILES}"
NEW_MODULES="wildcard"
TO_LOAD='wildcard'
